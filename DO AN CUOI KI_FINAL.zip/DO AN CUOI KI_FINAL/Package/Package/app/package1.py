import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd


def main(df=None):
    if df is None:
        df = pd.read_csv("ObesityData_EatingHabits_Cleaned.csv")
    ve_duong_hoat_dong_va_thiet_bi(df)
    ve_theo_nhom_tuoi(df)
    ve_theo_gioi_tinh(df)
    ve_theo_thoi_quen_an_uong(df)

def ve_duong_hoat_dong_va_thiet_bi(df):
    df = df[df['WeightStatus'].isin(['Overweight_Level_I', 'Overweight_Level_II', 'Obesity_Type_I', 'Obesity_Type_II', 'Obesity_Type_III'])]

    def nhom_phuong_tien(loai):
        if loai in ['Walking', 'Bike', 'Public_Transportation']:
            return 'Đi bộ/Xe đạp/Phương tiện công cộng'
        elif loai in ['Motorbike', 'Automobile']:
            return 'Xe máy/Oto'
        return 'Khác'

    df['NhomPhuongTien'] = df['TransportType'].apply(nhom_phuong_tien)

    hoat_dong = df.groupby(['PhysicalActivityFrequency', 'NhomPhuongTien']).size().reset_index(name='Số lượng người thừa cân và béo phì')
    thiet_bi = df.groupby(['TechDeviceUsage', 'NhomPhuongTien']).size().reset_index(name='Số lượng người thừa cân và béo phì')

    fig, axes = plt.subplots(1, 2, figsize=(14, 6), sharey=True)

    sns.lineplot(data=hoat_dong, x='PhysicalActivityFrequency', y='Số lượng người thừa cân và béo phì', hue='NhomPhuongTien', marker='o', ax=axes[0])
    axes[0].set_title('Số lượng người thừa cân và béo phì dựa trên cường độ hoạt động thể chất')
    axes[0].set_xlabel('Tần suất hoạt động thể chất')
    axes[0].set_ylabel('Số lượng người thừa cân và béo phì')
    axes[0].legend(title='Nhóm phương tiện', loc="upper right")

    sns.lineplot(data=thiet_bi, x='TechDeviceUsage', y='Số lượng người thừa cân và béo phì', hue='NhomPhuongTien', marker='o', ax=axes[1])
    axes[1].set_title('Số lượng người thừa cân và béo phì dựa trên thời gian sử dụng thiết bị điện tử')
    axes[1].set_xlabel('Thời gian sử dụng thiết bị điện tử')
    axes[1].set_ylabel('')
    axes[1].legend(title='Nhóm phương tiện', loc="lower left")
    plt.tight_layout()
    plt.show()

def ve_theo_nhom_tuoi(df):
    df['AgeGroup'] = pd.cut(df['Age'], bins=[0, 10, 20, 30, 40, 50, 60, 100],
                            labels=['0-10', '11-20', '21-30', '31-40', '41-50', '51-60', '61+'], right=False)
    thu_tu = [
        'Insufficient_Weight', 'Normal_Weight', 'Overweight_Level_I',
        'Overweight_Level_II', 'Obesity_Type_I', 'Obesity_Type_II', 'Obesity_Type_III']

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x='AgeGroup', hue='WeightStatus', palette='flare', hue_order=thu_tu)
    plt.title('Weight Status by Age Group')
    plt.xlabel('Age Group')
    plt.ylabel('Number of People')
    plt.legend(title='Weight Status', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.show()

def ve_theo_gioi_tinh(df):
    thu_tu = [
        'Insufficient_Weight', 'Normal_Weight', 'Overweight_Level_I',
        'Overweight_Level_II', 'Obesity_Type_I', 'Obesity_Type_II', 'Obesity_Type_III']
    palette = {'Male': 'dodgerblue', 'Female': 'hotpink'}

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x='WeightStatus', hue='Gender', palette=palette, order=thu_tu)
    plt.title('Weight Status by Gender')
    plt.xlabel('Weight Status')
    plt.ylabel('Number of People')
    plt.xticks(rotation=45)
    plt.legend(title='Gender')
    plt.tight_layout()
    plt.show()

def ve_theo_thoi_quen_an_uong(df):
    eating_order = ['VeryUnhealthy', 'Unhealthy', 'Average', 'Healthy', 'VeryHealthy']
    weight_order = [
        'Insufficient_Weight', 'Normal_Weight', 'Overweight_Level_I',
        'Overweight_Level_II', 'Obesity_Type_I', 'Obesity_Type_II', 'Obesity_Type_III']

    custom_palette = {
        'Insufficient_Weight': '#aec7e8',
        'Normal_Weight': '#98df8a',
        'Overweight_Level_I': '#ffbb78',
        'Overweight_Level_II': '#f0b27a',
        'Obesity_Type_I': '#ff9896',
        'Obesity_Type_II': '#e377c2',
        'Obesity_Type_III': '#c49c94'
    }

    plt.figure(figsize=(12, 7))
    sns.countplot(data=df, x='EatingHabits', hue='WeightStatus',
                  order=eating_order, hue_order=weight_order,
                  palette=custom_palette)
    plt.title('Weight Status by Eating Habits')
    plt.xlabel('Eating Habits')
    plt.ylabel('Number of People')
    plt.legend(title='Weight Status', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.show()