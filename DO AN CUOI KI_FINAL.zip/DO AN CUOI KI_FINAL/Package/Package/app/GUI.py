import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import pandas as pd
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Package.app import package1

class GiaoDien:
    def __init__(self, root):
        self.root = root
        self.root.title("Quản lý dữ liệu béo phì")
        self.du_lieu = pd.read_csv("ObesityData_EatingHabits_Cleaned.csv")
        self.du_lieu_goc = self.du_lieu.copy()
        self.trang = 0
        self.kich_thuoc = 20
        self.tao_giao_dien()
        self.hien_thi()

    def tao_giao_dien(self):
        khung = tk.Frame(self.root)
        khung.pack(fill=tk.BOTH, expand=True)

        cuon_doc = ttk.Scrollbar(khung, orient=tk.VERTICAL)
        self.bang = ttk.Treeview(khung, show="headings", yscrollcommand=cuon_doc.set)
        cuon_doc.config(command=self.bang.yview)
        cuon_doc.pack(side=tk.RIGHT, fill=tk.Y)
        self.bang.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.bang["columns"] = list(self.du_lieu.columns)
        for cot in self.du_lieu.columns:
            self.bang.heading(cot, text=cot)
            self.bang.column(cot, width=100)

        # Nút điều hướng
        nav = tk.Frame(self.root)
        nav.pack()
        ttk.Button(nav, text="Trang đầu", command=self.trang_dau).pack(side=tk.LEFT)
        ttk.Button(nav, text="Trước", command=self.truoc).pack(side=tk.LEFT)
        ttk.Button(nav, text="Sau", command=self.sau).pack(side=tk.LEFT)
        ttk.Button(nav, text="Trang cuối", command=self.trang_cuoi).pack(side=tk.LEFT)
        ttk.Button(nav, text="Tải lại", command=self.tai_lai).pack(side=tk.LEFT)

        # Nút chức năng
        chuc_nang = tk.Frame(self.root)
        chuc_nang.pack(pady=5)
        ttk.Button(chuc_nang, text="Tìm", command=self.tim).pack(side=tk.LEFT, padx=5)
        ttk.Button(chuc_nang, text="Lọc", command=self.loc).pack(side=tk.LEFT, padx=5)
        ttk.Button(chuc_nang, text="Quản lý", command=self.quan_ly).pack(side=tk.LEFT, padx=5)
        ttk.Button(chuc_nang, text="Vẽ biểu đồ", command=self.ve_bieu_do).pack(side=tk.LEFT, padx=5)
        ttk.Button(chuc_nang, text="Vẽ biểu đồ từ dữ liệu đã lọc", command=self.ve_bieu_do).pack(side=tk.LEFT, padx=5)

    def hien_thi(self):
        self.bang.delete(*self.bang.get_children())
        bd = self.trang * self.kich_thuoc
        kt = bd + self.kich_thuoc
        for _, dong in self.du_lieu.iloc[bd:kt].iterrows():
            self.bang.insert("", tk.END, values=list(dong))

    def trang_dau(self):
        self.trang = 0
        self.hien_thi()

    def truoc(self):
        if self.trang > 0:
            self.trang -= 1
            self.hien_thi()

    def sau(self):
        if (self.trang + 1) * self.kich_thuoc < len(self.du_lieu):
            self.trang += 1
            self.hien_thi()

    def trang_cuoi(self):
        self.trang = len(self.du_lieu) // self.kich_thuoc
        self.hien_thi()

    def tai_lai(self):
        try:
            self.du_lieu = pd.read_csv("ObesityData_EatingHabits_Cleaned.csv")
            self.du_lieu_goc = self.du_lieu.copy()
            self.trang = 0
            self.hien_thi()
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể tải lại dữ liệu gốc: {e}")

    def tim(self):
        try:
            nhap_id = simpledialog.askstring("Tìm kiếm", "Nhập số ID:")
            if nhap_id is not None:
                nhap_id = int(nhap_id)
                ket_qua = self.du_lieu_goc[self.du_lieu_goc['ID'] == nhap_id]
                if not ket_qua.empty:
                    self.du_lieu = ket_qua.copy()
                    self.trang = 0
                    self.hien_thi()
                else:
                    messagebox.showinfo("Không tìm thấy", f"Không tìm thấy bản ghi với ID: {nhap_id}")
        except ValueError:
            messagebox.showerror("Lỗi", "ID phải là một số nguyên hợp lệ.")

    def loc(self):
        cot = simpledialog.askstring("Lọc", "Nhập tên cột:")
        if not cot:
            return

        # Tìm cột khớp không phân biệt hoa/thường
        cot_khop = None
        for ten_cot in self.du_lieu.columns:
            if ten_cot.lower() == cot.lower():
                cot_khop = ten_cot
                break

        if cot_khop is None:
            messagebox.showerror("Lỗi", f"Không tìm thấy cột có tên '{cot}'")
            return

        gia_tri = simpledialog.askstring("Lọc", f"Nhập giá trị cần lọc trong cột '{cot_khop}':")
        if gia_tri is None:
            return

        # Lọc không phân biệt hoa/thường
        loc_ket_qua = self.du_lieu_goc[
            self.du_lieu_goc[cot_khop].astype(str).str.lower() == gia_tri.lower()
            ]

        if not loc_ket_qua.empty:
            self.du_lieu = loc_ket_qua.copy()
            self.trang = 0
            self.hien_thi()
        else:
            messagebox.showinfo("Không tìm thấy", f"Không có '{gia_tri}' trong cột '{cot_khop}'")

    def ve_bieu_do(self):
        try:
            package1.main(self.du_lieu)
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    def quan_ly(self):
        win = tk.Toplevel(self.root)
        win.title("Quản lý")
        bang = ttk.Treeview(win, show="headings")
        bang.pack(fill=tk.BOTH, expand=True)
        cot = list(self.du_lieu.columns)
        bang["columns"] = cot
        for c in cot:
            bang.heading(c, text=c)
            bang.column(c, width=100)
        for _, dong in self.du_lieu.iterrows():
            bang.insert("", tk.END, values=list(dong))

        def doc_ban_ghi(event):
            selected_item = bang.selection()
            if selected_item:
                values = bang.item(selected_item[0], "values")
                info = "\n".join(f"{cot[i]}: {values[i]}" for i in range(len(cot)))
                messagebox.showinfo("Chi tiết bản ghi", info)

        bang.bind("<Double-1>", doc_ban_ghi)

        def them():
            form = tk.Toplevel(win)
            bien = []
            for i, c in enumerate(cot):
                tk.Label(form, text=c).grid(row=i, column=0)
                v = tk.StringVar()
                tk.Entry(form, textvariable=v).grid(row=i, column=1)
                bien.append(v)
            def luu():
                moi = {c: bien[i].get() for i, c in enumerate(cot)}
                self.du_lieu = pd.concat([self.du_lieu, pd.DataFrame([moi])], ignore_index=True)
                self.du_lieu_goc = self.du_lieu.copy()
                bang.insert("", tk.END, values=list(moi.values()))
                self.hien_thi()
                form.destroy()
            tk.Button(form, text="Lưu", command=luu).grid(row=len(cot), columnspan=2)

        def xoa():
            chon = bang.selection()
            if not chon: return
            for sel in chon:
                gia_tri = bang.item(sel)["values"]
                self.du_lieu = self.du_lieu[self.du_lieu[cot[0]] != gia_tri[0]]
            self.du_lieu_goc = self.du_lieu.copy()
            bang.delete(*bang.get_children())
            for _, dong in self.du_lieu.iterrows():
                bang.insert("", tk.END, values=list(dong))
            self.hien_thi()

        def sua():
            chon = bang.selection()
            if not chon: return
            cu = bang.item(chon[0])["values"]
            form = tk.Toplevel(win)
            bien = []
            for i, c in enumerate(cot):
                tk.Label(form, text=c).grid(row=i, column=0)
                v = tk.StringVar(value=cu[i])
                tk.Entry(form, textvariable=v).grid(row=i, column=1)
                bien.append(v)
            def capnhat():
                moi = [v.get() for v in bien]
                for i in range(len(self.du_lieu)):
                    if all(str(self.du_lieu.iloc[i][cot[j]]) == str(cu[j]) for j in range(len(cot))):
                        for j in range(len(cot)):
                            self.du_lieu.at[i, cot[j]] = moi[j]
                        break
                self.du_lieu_goc = self.du_lieu.copy()
                bang.delete(*bang.get_children())
                for _, dong in self.du_lieu.iterrows():
                    bang.insert("", tk.END, values=list(dong))
                self.hien_thi()
                form.destroy()
            tk.Button(form, text="Cập nhật", command=capnhat).grid(row=len(cot), columnspan=2)

        nut = tk.Frame(win)
        nut.pack()
        tk.Button(nut, text="Thêm", command=them).pack(side=tk.LEFT)
        tk.Button(nut, text="Xóa", command=xoa).pack(side=tk.LEFT)
        tk.Button(nut, text="Sửa", command=sua).pack(side=tk.LEFT)


if __name__ == '__main__':
    goc = tk.Tk()
    app = GiaoDien(goc)
    goc.mainloop()
