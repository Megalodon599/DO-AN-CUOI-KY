import pandas as pd

# Load original dataset
df = pd.read_csv("[GỐC] ObesityDataSet_raw_and_data_sinthetic.csv")

# Rename columns
rename_dict = {
    'FAVC': 'HighCalorieFood',
    'FCVC': 'VeggieFrequency',
    'NCP': 'MainMealsPerDay',
    'CAEC': 'SnacksBetweenMeals',
    'SMOKE': 'Smoker',
    'CH2O': 'WaterIntake',
    'SCC': 'CalorieMonitoring',
    'FAF': 'PhysicalActivityFrequency',
    'TUE': 'TechDeviceUsage',
    'CALC': 'AlcoholConsumption',
    'MTRANS': 'TransportType',
    'NObeyesdad': 'WeightStatus'
}
df.rename(columns=rename_dict, inplace=True)

# Eating habits classification
def classify_eating_habits(row):
    if (
        row['HighCalorieFood'] == 'no' and
        row['VeggieFrequency'] >= 3 and
        row['MainMealsPerDay'] in [3, 4] and
        row['SnacksBetweenMeals'] == 'no' and
        row['Smoker'] == 'no' and
        row['WaterIntake'] >= 2 and
        row['CalorieMonitoring'] == 'yes' and
        row['PhysicalActivityFrequency'] >= 2.5 and
        row['AlcoholConsumption'] == 'no'
    ):
        return 'VeryHealthy'
    elif (
        row['HighCalorieFood'] == 'no' and
        row['VeggieFrequency'] >= 2.5 and
        row['MainMealsPerDay'] in [3, 4] and
        row['SnacksBetweenMeals'] in ['no', 'Sometimes'] and
        row['WaterIntake'] >= 1.5 and
        row['PhysicalActivityFrequency'] >= 1.5 and
        row['AlcoholConsumption'] in ['no', 'Sometimes']
    ):
        return 'Healthy'
    elif (
        row['VeggieFrequency'] >= 2 and
        row['MainMealsPerDay'] >= 2 and
        row['WaterIntake'] >= 1 and
        row['PhysicalActivityFrequency'] >= 1
    ):
        return 'Average'
    elif (
        row['HighCalorieFood'] == 'yes' and
        row['VeggieFrequency'] < 2 and
        row['SnacksBetweenMeals'] in ['Frequently', 'Always'] and
        row['WaterIntake'] < 2 and
        row['CalorieMonitoring'] == 'no' and
        row['PhysicalActivityFrequency'] < 1
    ):
        return 'Risky'
    else:
        return 'VeryUnhealthy'

# Apply classification
df['EatingHabits'] = df.apply(classify_eating_habits, axis=1)

# Save updated dataset
df.to_csv("ObesityData_EatingHabits_Updated.csv", index=False)
print("Dataset updated and saved.")